Java self prepared material with working sample code examples.
